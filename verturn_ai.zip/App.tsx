import React, { useState, useEffect } from 'react';
import { SERVICES, CRMS, PORTFOLIO, TESTIMONIALS, VIDEOS } from './constants';
import AIChatAssistant from './components/AIChatAssistant';
import ServiceDetail from './components/ServiceDetail';

const Header: React.FC<{ onNavigateHome: () => void }> = ({ onNavigateHome }) => (
  <header className="fixed top-0 w-full z-50 glass-light border-b border-slate-200">
    <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
      <div className="flex items-center gap-2 cursor-pointer group" onClick={onNavigateHome}>
        <div className="w-8 h-8 bg-orange-600 rounded flex items-center justify-center font-bold text-xl text-white shadow-md group-hover:scale-110 transition-transform">V</div>
        <span className="font-black text-lg md:text-xl tracking-tighter uppercase whitespace-nowrap text-slate-900">Verturn Technologies</span>
      </div>
      <nav className="hidden lg:flex gap-8 text-xs font-bold uppercase tracking-widest text-slate-500">
        <button onClick={onNavigateHome} className="hover:text-orange-600 transition-colors">Home</button>
        <a href="#services" onClick={onNavigateHome} className="hover:text-orange-600 transition-colors">Expertise</a>
        <a href="#portfolio" onClick={onNavigateHome} className="hover:text-orange-600 transition-colors uppercase">Portfolio</a>
        <button 
          onClick={() => {
            onNavigateHome();
            setTimeout(() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' }), 100);
          }}
          className="hover:text-orange-600 transition-colors uppercase"
        >
          Contact
        </button>
      </nav>
      <button 
        onClick={() => {
          onNavigateHome();
          setTimeout(() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' }), 100);
        }}
        className="bg-orange-600 text-white px-6 py-2.5 rounded-full text-xs font-bold hover:bg-orange-700 hover:scale-105 transition-all shadow-lg shadow-orange-600/20"
      >
        Free Consultation
      </button>
    </div>
  </header>
);

const Hero: React.FC = () => (
  <section className="relative min-h-[90vh] flex flex-col items-center justify-center pt-32 pb-20 overflow-hidden px-6 bg-grid">
    <div className="absolute inset-0 bg-gradient-to-b from-orange-50/50 via-slate-50 to-slate-50 -z-10"></div>
    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-orange-200/20 blur-[100px] rounded-full -z-10"></div>
    
    <div className="max-w-5xl mx-auto text-center relative z-10">
      <div className="inline-block px-4 py-2 rounded-full bg-white border border-slate-200 text-orange-600 text-[10px] md:text-xs font-bold uppercase tracking-[0.3em] mb-8 shadow-sm">
        Victor Afe | Lead AI Consultant
      </div>
      <h1 className="text-5xl md:text-7xl lg:text-8xl font-black mb-8 leading-[1.1] tracking-tighter text-slate-900">
        SCALE WITH <br /> <span className="text-orange-600">AI PRECISION.</span>
      </h1>
      <p className="text-lg md:text-2xl text-slate-500 mb-12 max-w-3xl mx-auto leading-relaxed px-4">
        Engineering bespoke automation, high-performance voice agents, and deep CRM logic. We don't just innovate; we build your unfair advantage.
      </p>
      <div className="flex flex-col sm:flex-row gap-5 justify-center">
        <button 
          onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
          className="bg-slate-900 text-white px-10 py-4 rounded-2xl font-black text-lg hover:bg-black transition-all shadow-xl active:scale-95"
        >
          Get Started
        </button>
        <button 
          onClick={() => document.getElementById('portfolio')?.scrollIntoView({ behavior: 'smooth' })}
          className="border border-slate-200 bg-white text-slate-900 px-10 py-4 rounded-2xl font-black text-lg hover:border-orange-600 hover:text-orange-600 transition-all shadow-sm active:scale-95"
        >
          View Case Studies
        </button>
      </div>
    </div>
    
    <div className="mt-20 flex gap-8 opacity-40 flex-wrap justify-center max-w-4xl mx-auto px-4">
      {CRMS.map(c => <span key={c} className="text-[10px] md:text-xs font-bold tracking-[0.4em] uppercase text-slate-400">{c}</span>)}
    </div>
  </section>
);

const Services: React.FC<{ onSelectService: (id: string) => void }> = ({ onSelectService }) => (
  <section id="services" className="py-32 max-w-7xl mx-auto px-6 relative bg-white rounded-[4rem] shadow-sm z-10 -mt-10 border border-slate-100">
    <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-20 gap-8">
      <div className="max-w-2xl">
        <h2 className="text-4xl md:text-6xl font-black mb-6 leading-tight text-slate-900">Our Expertise</h2>
        <p className="text-slate-500 text-lg md:text-xl max-w-xl">Intelligent systems designed to eliminate bottlenecks and maximize throughput.</p>
      </div>
    </div>

    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
      {SERVICES.map(s => (
        <div 
          key={s.id} 
          onClick={() => onSelectService(s.id)}
          className="group p-10 bg-slate-50/50 border border-slate-200 rounded-3xl hover:border-orange-600/30 transition-all hover:-translate-y-2 relative overflow-hidden cursor-pointer hover:shadow-2xl hover:bg-white"
        >
          <div className="absolute top-0 right-0 p-8 text-7xl opacity-[0.05] group-hover:opacity-10 transition-opacity grayscale">{s.icon}</div>
          <div className="text-5xl mb-8 relative z-10">{s.icon}</div>
          <h3 className="text-2xl font-bold mb-4 relative z-10 text-slate-900">{s.title}</h3>
          <p className="text-slate-500 text-sm md:text-base mb-8 leading-relaxed relative z-10">{s.description}</p>
          <div className="flex items-center gap-3 text-orange-600 text-xs font-bold uppercase tracking-widest relative z-10">
            <span>Learn More Details</span>
            <span className="group-hover:translate-x-3 transition-transform">→</span>
          </div>
        </div>
      ))}
    </div>
  </section>
);

const VideosSection: React.FC = () => (
  <section id="videos" className="py-32 bg-slate-50 px-6">
    <div className="max-w-7xl mx-auto">
      <div className="text-center mb-20">
        <h2 className="text-4xl md:text-6xl font-black mb-6 text-slate-900 tracking-tighter">AI Insights</h2>
        <p className="text-slate-500 text-lg md:text-xl max-w-2xl mx-auto">Watch how Verturn is reshaping the enterprise landscape.</p>
      </div>

      <div className="grid lg:grid-cols-12 gap-10">
        <div className="lg:col-span-8 group cursor-pointer">
          <div className="relative aspect-video rounded-3xl overflow-hidden border border-slate-200 bg-white shadow-xl">
            <img src={VIDEOS[0].thumbnail} alt={VIDEOS[0].title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
            <div className="absolute inset-0 bg-slate-900/10 flex items-center justify-center">
               <div className="w-20 h-20 bg-orange-600 rounded-full flex items-center justify-center shadow-2xl scale-90 group-hover:scale-100 transition-transform">
                  <div className="w-0 h-0 border-t-[12px] border-t-transparent border-l-[20px] border-l-white border-b-[12px] border-b-transparent ml-2"></div>
               </div>
            </div>
            <div className="absolute bottom-8 left-8 right-8">
               <span className="bg-orange-600 text-white text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-md mb-3 inline-block shadow-lg">Featured Demo</span>
               <h3 className="text-2xl md:text-3xl font-black text-white drop-shadow-lg mb-2">{VIDEOS[0].title}</h3>
               <p className="text-white text-sm md:text-base line-clamp-1 opacity-90">{VIDEOS[0].description}</p>
            </div>
          </div>
        </div>

        <div className="lg:col-span-4 flex flex-col gap-8">
          {VIDEOS.slice(1).map(video => (
            <div key={video.id} className="group cursor-pointer flex flex-col sm:flex-row lg:flex-col gap-5">
              <div className="relative aspect-video sm:w-48 lg:w-full rounded-2xl overflow-hidden border border-slate-200 shrink-0 shadow-sm">
                <img src={video.thumbnail} alt={video.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                <div className="absolute inset-0 bg-slate-900/10 flex items-center justify-center">
                  <div className="w-10 h-10 bg-white/40 backdrop-blur-sm rounded-full flex items-center justify-center border border-white/30">
                     <div className="w-0 h-0 border-t-[5px] border-t-transparent border-l-[8px] border-l-slate-900 border-b-[5px] border-b-transparent ml-1"></div>
                  </div>
                </div>
              </div>
              <div>
                <h4 className="font-bold text-lg mb-2 group-hover:text-orange-600 transition-colors line-clamp-1 text-slate-900">{video.title}</h4>
                <p className="text-slate-500 text-xs md:text-sm line-clamp-2 leading-relaxed">{video.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  </section>
);

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<'home' | 'detail'>('home');
  const [selectedServiceId, setSelectedServiceId] = useState<string | null>(null);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [currentPage, selectedServiceId]);

  const navigateToDetail = (id: string) => {
    setSelectedServiceId(id);
    setCurrentPage('detail');
  };

  const navigateHome = () => {
    setCurrentPage('home');
    setSelectedServiceId(null);
  };

  if (currentPage === 'detail' && selectedServiceId) {
    return (
      <main className="relative bg-slate-50 text-slate-900 selection:bg-orange-600 selection:text-white min-h-screen">
        <Header onNavigateHome={navigateHome} />
        <ServiceDetail serviceId={selectedServiceId} onBack={navigateHome} />
        <AIChatAssistant />
      </main>
    );
  }

  return (
    <main className="relative bg-slate-50 text-slate-900 selection:bg-orange-600 selection:text-white min-h-screen">
      <Header onNavigateHome={navigateHome} />
      <Hero />
      <Services onSelectService={navigateToDetail} />
      
      <section id="portfolio" className="py-32 bg-white px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <h2 className="text-4xl md:text-6xl font-black mb-6 text-slate-900 tracking-tighter">Case Studies</h2>
            <p className="text-slate-500 text-lg md:text-xl max-w-2xl mx-auto">Proof that automation is the new standard for business growth.</p>
          </div>
          <div className="grid md:grid-cols-2 gap-10">
            {PORTFOLIO.map(item => (
              <div key={item.id} className="bg-slate-50 border border-slate-200 rounded-3xl overflow-hidden flex flex-col md:flex-row group transition-all hover:border-orange-600/30 shadow-sm hover:shadow-xl hover:bg-white">
                <div className="w-full md:w-1/3 bg-orange-600/5 flex items-center justify-center p-10 border-b md:border-b-0 md:border-r border-slate-200">
                  <div className="text-center">
                    <div className="text-orange-600 font-black text-5xl mb-3">{item.result.split(' ')[0]}</div>
                    <div className="text-[10px] text-slate-400 uppercase tracking-widest font-black leading-tight">{item.result.split(' ').slice(1).join(' ')}</div>
                  </div>
                </div>
                <div className="p-10 flex-1 flex flex-col justify-center">
                  <div className="text-orange-600 text-[10px] font-black uppercase tracking-[0.2em] mb-3">{item.category}</div>
                  <h3 className="text-2xl font-bold mb-4 text-slate-900">{item.title}</h3>
                  <p className="text-slate-500 text-sm md:text-base leading-relaxed">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <VideosSection />
      
      <section id="testimonials" className="py-32 max-w-7xl mx-auto px-6 bg-slate-50">
        <div className="grid md:grid-cols-3 gap-8">
          {TESTIMONIALS.map(t => (
            <div key={t.id} className="p-10 bg-white border border-slate-200 rounded-3xl relative flex flex-col shadow-sm hover:shadow-md transition-shadow">
              <div className="text-orange-600 text-8xl absolute top-4 right-8 opacity-5 font-serif leading-none">"</div>
              <p className="text-slate-600 italic mb-10 text-lg leading-relaxed relative z-10 flex-1">"{t.content}"</p>
              <div className="flex items-center gap-5 mt-auto relative z-10">
                <div className="w-14 h-14 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center font-black text-xl text-orange-600 shadow-inner">
                  {t.name.charAt(0)}
                </div>
                <div>
                  <div className="font-bold text-lg text-slate-900">{t.name}</div>
                  <div className="text-xs text-orange-600 uppercase tracking-widest font-black">{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
      
      <section id="contact" className="py-32 bg-slate-900 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-orange-600 opacity-[0.03]"></div>
        <div className="max-w-5xl mx-auto px-6 text-center relative z-10">
          <h2 className="text-5xl md:text-7xl font-black mb-8 leading-tight tracking-tighter">LET'S BUILD THE <br />FUTURE TOGETHER</h2>
          <p className="text-xl md:text-3xl mb-16 opacity-70 font-light max-w-3xl mx-auto leading-relaxed text-slate-300">Schedule a high-level consultation with Victor Afe.</p>
          
          <div className="bg-white/5 p-8 md:p-12 rounded-[2.5rem] border border-white/10 backdrop-blur-xl max-w-4xl mx-auto shadow-2xl">
             <form className="grid md:grid-cols-2 gap-6" onSubmit={(e) => e.preventDefault()}>
               <div className="flex flex-col text-left gap-2">
                 <label className="text-[10px] uppercase tracking-widest font-black opacity-50 ml-2">Full Name</label>
                 <input className="bg-white/5 border border-white/10 p-5 rounded-2xl placeholder:text-white/20 text-white outline-none focus:ring-2 focus:ring-orange-600 transition-all" placeholder="John Doe" />
               </div>
               <div className="flex flex-col text-left gap-2">
                 <label className="text-[10px] uppercase tracking-widest font-black opacity-50 ml-2">Work Email</label>
                 <input className="bg-white/5 border border-white/10 p-5 rounded-2xl placeholder:text-white/20 text-white outline-none focus:ring-2 focus:ring-orange-600 transition-all" placeholder="john@company.com" />
               </div>
               <div className="md:col-span-2 flex flex-col text-left gap-2">
                 <label className="text-[10px] uppercase tracking-widest font-black opacity-50 ml-2">Your Business Goals</label>
                 <textarea className="bg-white/5 border border-white/10 p-5 rounded-2xl h-40 placeholder:text-white/20 text-white outline-none focus:ring-2 focus:ring-orange-600 transition-all resize-none" placeholder="How can Victor help your business reach the next level?"></textarea>
               </div>
               <button className="md:col-span-2 bg-orange-600 text-white font-black py-5 rounded-2xl text-xl hover:bg-orange-700 hover:scale-[1.02] active:scale-95 transition-all shadow-2xl flex items-center justify-center gap-3">
                 <span>REQUEST AI AUDIT</span>
                 <span className="text-2xl">→</span>
               </button>
             </form>
          </div>
        </div>
      </section>

      <footer className="py-20 bg-white border-t border-slate-100 text-slate-500 text-center relative z-10">
        <div className="mb-6 flex justify-center items-center gap-2">
           <div className="w-8 h-8 bg-slate-900 rounded flex items-center justify-center font-bold text-white shadow-md">V</div>
           <span className="text-slate-900 font-black tracking-tighter uppercase">Verturn</span>
        </div>
        <p>© {new Date().getFullYear()} Victor Afe. Verturn Technologies.</p>
      </footer>

      <AIChatAssistant />
    </main>
  );
};

export default App;