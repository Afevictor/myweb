import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://txsvxlzjwrwqrjumkhig.supabase.co';
const supabaseKey = 'sb_publishable_aPDI-zn73mGH4Qs1mJMFgQ_LP_qAy0r';

export const supabase = createClient(supabaseUrl, supabaseKey);