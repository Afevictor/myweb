import React from 'react';
import { SERVICES } from '../constants';

interface Props {
  serviceId: string;
  onBack: () => void;
}

const ServiceDetail: React.FC<Props> = ({ serviceId, onBack }) => {
  const service = SERVICES.find(s => s.id === serviceId);

  const details: Record<string, { fullTitle: string; content: string; keyBenefits: string[]; image: string }> = {
    'ai-automation': {
      fullTitle: 'Enterprise-Grade AI CRM & Workflow Automation',
      content: 'We take your existing manual processes and turn them into autonomous engines. By integrating Salesforce, HubSpot, and GoHighLevel with advanced AI logic, we ensure that every lead is captured, every task is logged, and every follow-up is perfectly timed without a single click from your team.',
      keyBenefits: [
        'Zero manual data entry for sales teams.',
        'Real-time lead scoring and prioritization.',
        'Seamless multi-platform data synchronization.',
        'Automated document generation and e-signing.'
      ],
      image: 'https://images.unsplash.com/photo-1551288049-bbbda536339a?auto=format&fit=crop&q=80&w=1200'
    },
    'ai-voice-agents': {
      fullTitle: 'High-Performance AI Voice & Chat Solutions',
      content: 'Never let a call go unanswered again. Our proprietary voice agents handle inbound inquiries and outbound booking with near-human synthesis and zero latency. These aren\'t simple "press 1 for help" bots; they are trained on your business logic to close appointments and support customers 24/7.',
      keyBenefits: [
        'Human-like conversational flow and empathy.',
        'Direct calendar integration (Calendly/GHL).',
        'Significant reduction in customer support overhead.',
        'Multilingual support for global operations.'
      ],
      image: 'https://images.unsplash.com/photo-1589254065878-42c9da997008?auto=format&fit=crop&q=80&w=1200'
    },
    'ai-lead-gen': {
      fullTitle: 'Autonomous Lead Generation & Smart Nurturing',
      content: 'Our systems crawl the web to find your ideal prospects and initiate contact automatically. Once a lead is found, our AI nurturing sequence takes over, using context-aware messaging to build trust until they are ready to book a call with your human team.',
      keyBenefits: [
        'Automated prospecting at scale.',
        'Dynamic follow-up based on user behavior.',
        'Higher conversion rates from cold outreach.',
        'Comprehensive lead tracking and attribution.'
      ],
      image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=1200'
    },
    'ai-security': {
      fullTitle: 'AI Red Teaming & Security Infrastructure',
      content: 'AI is your greatest asset and your biggest liability. We stress-test your LLM deployments for prompt injections, data leakage, and adversarial vulnerabilities. Victor Afe provides a full security audit to ensure your AI behaves exactly as intended, protecting your brand and data.',
      keyBenefits: [
        'Comprehensive vulnerability assessments.',
        'Protection against prompt injection attacks.',
        'Regulatory compliance and safety filters.',
        'Ongoing monitoring for model drift and misuse.'
      ],
      image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=1200'
    },
    'ai-video': {
      fullTitle: 'Automated AI Video Content Pipelines',
      content: 'Content is king, but creation is a bottleneck. We build automated pipelines that turn text scripts or blog posts into professional, high-engagement videos for social media. Scalable, consistent, and perfectly on-brand every single time.',
      keyBenefits: [
        '10x faster content production cycles.',
        'Automated subtitling and visual editing.',
        'Consistent brand voice across all media.',
        'Significant reduction in video editor costs.'
      ],
      image: 'https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?auto=format&fit=crop&q=80&w=1200'
    },
    'training': {
      fullTitle: 'Enterprise AI Strategy & Training Workshops',
      content: 'Technology is only as good as the team using it. Victor Afe provides high-level consultation for executives and hands-on training for staff. We bridge the gap between AI potential and practical, profitable deployment within your organization.',
      keyBenefits: [
        'Customized AI roadmaps for ROI.',
        'Hands-on staff training for AI tools.',
        'Executive coaching on the future of AI.',
        'Ongoing support and technology updates.'
      ],
      image: 'https://images.unsplash.com/photo-1524178232363-1fb2b075b655?auto=format&fit=crop&q=80&w=1200'
    }
  };

  const currentDetail = details[serviceId] || details['ai-automation'];

  return (
    <div className="pt-32 pb-20 bg-slate-50 min-h-screen relative overflow-hidden bg-grid">
      <div className="absolute top-1/4 right-0 w-[500px] h-[500px] bg-orange-200/20 blur-[100px] rounded-full -z-10"></div>
      
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <button 
          onClick={onBack}
          className="text-orange-600 font-bold mb-10 flex items-center gap-2 hover:translate-x-[-4px] transition-transform"
        >
          ← Back to Home
        </button>

        <div className="grid lg:grid-cols-2 gap-16 items-start">
          <div className="space-y-10">
            <div className="space-y-4">
              <span className="text-orange-600 text-xs font-black uppercase tracking-[0.3em]">{service?.category}</span>
              <h1 className="text-4xl md:text-6xl font-black leading-tight text-slate-900">{currentDetail.fullTitle}</h1>
            </div>
            
            <p className="text-slate-500 text-xl leading-relaxed">
              {currentDetail.content}
            </p>

            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-slate-900">Why This Matters:</h3>
              <ul className="grid md:grid-cols-2 gap-4">
                {currentDetail.keyBenefits.map((benefit, i) => (
                  <li key={i} className="flex gap-3 items-start p-5 bg-white rounded-xl border border-slate-200 shadow-sm">
                    <span className="text-orange-600 font-bold">✓</span>
                    <span className="text-slate-600 text-sm leading-tight font-medium">{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="p-10 bg-slate-900 rounded-[2.5rem] space-y-6 shadow-2xl relative overflow-hidden group">
               <div className="absolute inset-0 bg-orange-600/5 group-hover:opacity-0 transition-opacity"></div>
               <h3 className="text-3xl font-black text-white relative z-10">The Verturn Edge</h3>
               <p className="text-slate-300 text-lg relative z-10 leading-relaxed">
                 We don't just "set up" AI; we build custom-engineered systems that talk to your CRM, book your meetings, and secure your future.
               </p>
               <button 
                 onClick={() => {
                   onBack();
                   setTimeout(() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' }), 300);
                 }}
                 className="w-full bg-orange-600 text-white font-black py-5 rounded-2xl text-xl hover:bg-orange-700 hover:scale-[1.02] active:scale-95 transition-all shadow-xl relative z-10"
               >
                 REQUEST YOUR CUSTOM BUILD
               </button>
            </div>
          </div>

          <div className="relative">
             <div className="absolute -inset-10 bg-orange-200/30 blur-3xl rounded-full"></div>
             <div className="relative rounded-[3rem] overflow-hidden border border-slate-200 shadow-2xl group bg-white">
               <img 
                 src={currentDetail.image} 
                 alt={currentDetail.fullTitle} 
                 className="w-full aspect-[4/5] object-cover group-hover:scale-105 transition-transform duration-1000"
               />
               <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent flex flex-col justify-end p-10">
                  <div className="bg-white/90 backdrop-blur-md border border-slate-200 p-8 rounded-3xl shadow-2xl">
                    <p className="text-slate-900 font-bold italic text-lg leading-relaxed">"Victor's approach to AI isn't just about software; it's about business transformation. This is the ROI we've been waiting for."</p>
                    <p className="text-orange-600 text-xs font-black uppercase tracking-widest mt-4">— Tech Industry Founder</p>
                  </div>
               </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServiceDetail;