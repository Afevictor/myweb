
import { Service, PortfolioItem, Testimonial } from './types';

export const SERVICES: Service[] = [
  {
    id: 'ai-automation',
    title: 'AI Automation & CRM',
    description: 'Workflow optimization using Salesforce, HubSpot, Zoho, and Zapier to eliminate manual tasks.',
    category: 'Automation',
    icon: '⚡'
  },
  {
    id: 'ai-voice-agents',
    title: 'AI Voice & Chatbots',
    description: 'Next-gen appointment booking bots and 24/7 customer support agents with human-like voice capabilities.',
    category: 'Automation',
    icon: '🎙️'
  },
  {
    id: 'ai-lead-gen',
    title: 'Lead Gen & Follow-up',
    description: 'Automated lead scraping and smart follow-up systems that never let a prospect go cold.',
    category: 'Automation',
    icon: '📈'
  },
  {
    id: 'ai-security',
    title: 'AI Red Teaming & Security',
    description: 'Stress-testing AI models and implementing security statistics to safeguard enterprise deployments.',
    category: 'Security',
    icon: '🛡️'
  },
  {
    id: 'ai-video',
    title: 'AI Video Production',
    description: 'End-to-end video automation for content creators and marketing teams.',
    category: 'Development',
    icon: '🎬'
  },
  {
    id: 'training',
    title: 'Enterprise Training',
    description: 'Custom AI workshops and consultations for institutions looking to stay ahead of the curve.',
    category: 'Consulting',
    icon: '🎓'
  }
];

export const PORTFOLIO: PortfolioItem[] = [
  {
    id: '1',
    title: 'Real Estate Voice Closer',
    category: 'Voice Agents',
    description: 'Custom AI voice agent that qualifies leads and books appointments directly into HighLevel.',
    result: '40% increase in lead conversion',
    tags: ['GoHighLevel', 'AI Voice', 'Automation']
  },
  {
    id: '2',
    title: 'Enterprise CRM Sync',
    category: 'CRM Automation',
    description: 'Complex data bridge between Salesforce and HubSpot for a global logistics firm.',
    result: '150+ hours saved monthly',
    tags: ['Salesforce', 'HubSpot', 'Zapier']
  },
  {
    id: '3',
    title: 'Content Engine AI',
    category: 'Video Automation',
    description: 'Automated video pipeline that turns blog posts into viral social media shorts.',
    result: '1M+ views in 30 days',
    tags: ['Python', 'Video AI', 'Social Media']
  },
  {
    id: '4',
    title: 'AI Red Team Audit',
    category: 'Security',
    description: 'Security stress-test and vulnerability assessment for a FinTech startup\'s AI chatbot.',
    result: 'Identified 12 critical exploits',
    tags: ['Red Teaming', 'LLM Security', 'FinTech']
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: '1',
    name: 'Sarah Jenkins',
    role: 'CEO, Nexus Growth',
    content: 'Victor transformed our lead follow-up. The AI agent sounds so human our customers don\'t even realize they are talking to a bot. Incredible ROI.'
  },
  {
    id: '2',
    name: 'Mark Thompson',
    role: 'Ops Director, SolarScale',
    content: 'Verturn Technologies built a Salesforce automation that literally replaced three manual data entry roles. Highly recommend Victor for any CRM work.'
  },
  {
    id: '3',
    name: 'Elena Rodriguez',
    role: 'Founder, ContentPulse',
    content: 'The video automation pipeline Victor built is a game changer. We went from posting 3 times a week to 3 times a day without hiring anyone.'
  }
];

export const VIDEOS = [
  {
    id: 'v1',
    title: 'The Future of AI Voice Agents',
    description: 'Watch a live demo of our proprietary voice synthesis technology closing leads.',
    duration: '04:20',
    thumbnail: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'v2',
    title: 'Salesforce & AI Integration',
    description: 'Deep dive into how we bridge enterprise CRMs with autonomous agents.',
    duration: '06:15',
    thumbnail: 'https://images.unsplash.com/photo-1551288049-bbbda536339a?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'v3',
    title: 'AI Red Teaming Secrets',
    description: 'Learn how we stress-test models to prevent prompt injection and data leaks.',
    duration: '05:45',
    thumbnail: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=800'
  }
];

export const CRMS = ['Salesforce', 'HighLevel', 'HubSpot', 'Zoho CRM', 'Pebble', 'Square'];

export const SYSTEM_INSTRUCTION = `
You are the personal AI Assistant for Victor Afe, the Lead AI Consultant at Verturn Technologies.
Victor is an expert in AI automation, appointment booking bots, voice agents, red teaming, and CRM automation.
Your goal is to answer questions about Victor's services, his expertise, and help visitors understand how he can help their business.
Key services: AI Automation, Voice Agents, CRM (Salesforce/HubSpot), AI Security, Training.
Tone: Professional, high-tech, confident, yet helpful.
If a user asks to book a meeting, direct them to the "Book a Consultation" section.
`;
